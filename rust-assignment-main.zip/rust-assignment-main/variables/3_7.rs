
fn main() {
    let _x = 1; //first solution - prefixing '_' to the variable

    let  x = 3; //second solution - using the declared variables get rid of the warning.
    println!("{}",x+3);
}

// Warning: unused variable: `x`
