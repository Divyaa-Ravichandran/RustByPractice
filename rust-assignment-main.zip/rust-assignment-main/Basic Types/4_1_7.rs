
//  Replace ? with your answer
fn main() {
    let x = 1_000.000_1; // f32
    let y: f32 = 0.12; // f32
    let z = 0.01_f64; // f64

    println!("Success!");
}
