fn main() {
    print();
 }
 
 // Replace i32 with another type
 fn print()  {
    println!("Success!");
 }
 