
// Make println! work
fn main() {
    let _f: bool = false;

    let t = true; //or making it false can work too1
    if t {
        println!("Success!");
    }
} 
