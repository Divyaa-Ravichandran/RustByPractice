// Remove something to make it work
fn main() {
    let x: i32 = 5;
    let mut y: i32 = 5;  //when shadowing, the types has to be same.

    y = x;
    
    let z = 10; // Type of z ? 

    println!("Success!");
}
