
//  Fill the blank
fn main() {
    let v: u16 = 38_u8 as u16;  //Converting 38(u8)  to 38(u16)

    println!("Success!");
}