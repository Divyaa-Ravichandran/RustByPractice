
// FILL in the blank in two ways

use std::collections::{HashMap,BTreeMap,HashSet};
use std::collections::*;

fn main() {
    let mut c1:HashMap<&str, i32> = HashMap::new();
    let mut c2 = BTreeMap::new();
    c2.insert(1, "a");
    let mut c3: HashSet<i32> = HashSet::new();
}
