The file contents are - 

Cargo.lock
Cargo.toml
src
    main.rs
    lib.rs