use std::fmt::Result;
use std::io::Result as IoResult;

fn main() {}
