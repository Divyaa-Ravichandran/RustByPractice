hello-package has a binary crate and we have named it as hello-package.

src/main.rs is the crate root.


hello-package1 has a library crate named hello-package1.

src/lib.rs is the crate root.