cargo new --lib hello-package1
