// in src/main.rs

fn main() {
    assert_eq!(crate::front_of_house::hosting::seat_at_table(), "sit down please");
    assert_eq!(hello_package::,"yummy yummy!");
}
