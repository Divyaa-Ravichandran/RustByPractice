// FILL in the blank
// in lib.rs

mod front_of_house {
    mod hosting{
        fn add_to_waitlist(){}
        fn seat_at_table(){}
    }
    mod serving{
        fn take_order(){}
        fn server_order(){}
        fn take_payment(){}
        fn complain(){}
    }
}
