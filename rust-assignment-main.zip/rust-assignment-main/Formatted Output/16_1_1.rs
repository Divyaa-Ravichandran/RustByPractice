
fn main() {
    let s1 = "hello";
    let s = format!("{}, world!",s1);
    assert_eq!(s, "hello, world!");
}
