
fn main() {
    /*  to make it print:
    Hello world, I am 
    Sunface!
    */
    print!("Hello world, ");
    println!("I am");
    print!("Sunface!");
 }
 