All these exercises has been done from [practice.rs](practice.rs)

