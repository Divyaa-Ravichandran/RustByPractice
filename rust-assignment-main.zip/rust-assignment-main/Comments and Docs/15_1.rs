
/* Make it work, only using comments! */
fn main() {
    // todo!();
    // unimplemented!();
 
     assert_eq!(6, 5 +/* 3 + 2 +*/ 1 )
 }
 