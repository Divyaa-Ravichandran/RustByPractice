
fn main() {
    // Fill the blank with proper array type
    let arr: [i32;4] = [1, 2, 3, 4]; //changing type by removing one element

    // Modify the code below to make it work
    assert!(arr.len() == 4);

    println!("Success!");
}
