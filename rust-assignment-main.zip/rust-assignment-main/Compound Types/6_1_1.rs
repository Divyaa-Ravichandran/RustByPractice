
// Fix error without adding new line
fn main() {
    let s: &str = "hello, world"; //modified type as &str

    println!("Success!");
}
