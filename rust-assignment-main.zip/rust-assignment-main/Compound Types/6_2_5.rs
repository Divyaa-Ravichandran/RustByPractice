
fn main() {
    let arr = ['a', 'b', 'c'];
    
    let ele = arr[0]; //Indexing starts at 0.

    assert!(ele == 'a');

    println!("Success!");
}
