
// Make it work
fn main() {
    let t = ("i", "am", "sunface");
    assert_eq!(t.2, "sunface");  //Tuple elements have index number and can be accessed using it

    println!("Success!");
}
