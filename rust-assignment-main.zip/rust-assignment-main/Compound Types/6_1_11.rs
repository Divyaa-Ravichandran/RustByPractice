
fn main() {
    let s1 = String::from("hi,中国");
    let h = &s1[0..1];// added range as well as reference
    assert_eq!(h, "h");

    let h1 = &s1[3..5]; // Modify this line to fix the error, tips: `中`  takes 3 bytes in UTF8 format
    assert_eq!(h1, "中");

    println!("Success!");
}
