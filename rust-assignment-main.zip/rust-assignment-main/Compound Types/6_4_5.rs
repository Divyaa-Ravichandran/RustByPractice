fn main() {
    let (x, y, z);

    // Fill the blank
    (y,z,x) = (1, 2, 3);  // Destructuring assignments.
    
    assert_eq!(x, 3);
    assert_eq!(y, 1);
    assert_eq!(z, 2);

    println!("Success!");
}
